    </main>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> PlacaPay</p>
    </footer>
</body>
</html>